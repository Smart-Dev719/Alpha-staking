import React from 'react'
import Banner from './components/bannner/Banner'
import Header from './components/nav/Header'
import Wallet from './components/wallet/Wallet'

export default function App() {
    return (
        <>
            <Header />
            {/* <Banner /> */}
            <Wallet />
        </>
    )
}
